# 贡献指南

## 分支模型

| 分支 | 用途 |
|---|---|
| `main` | 始终保持可编译、可运行 |
| `feature/xxx` | 新功能开发，例如 `feature/decrypt` |
| `hotfix/xxx` | 文档补充、小缺陷修复，例如 `hotfix/doc-a` |

所有改动都通过 Pull Request 合入 `main`，不在 `main` 上直接提交。

## 提交信息格式

```
<类型>: <简短说明>
```

类型包括 `feat`、`fix`、`docs`、`test`、`refactor`。例如：

```
feat: 增加逆字节替代 InvSubBytes
docs: README 补充 Windows 编译说明
```

## 工作流程

```bash
git checkout main
git pull origin main
git checkout -b feature/your-feature
# 修改代码并自测
git add .
git commit -m "feat: 说明"
git push -u origin feature/your-feature
```

然后在 GitHub 上发起 PR，描述里写清改动内容和验证方式，等待合并。

## 代码要求

- 函数名和内部变量保留学号后两位后缀，便于课程核对
- 新增变换后，必须在 README 的示例输出中给出对应中间值
- 提交前用 `gcc -Wall` 编译，不应出现警告

## Issue 规范

提出问题或需求时请说明：

1. 使用的操作系统和编译器版本
2. 输入的数据
3. 期望输出与实际输出

功能类 issue 请使用 `enhancement` 标签，文档类使用 `documentation` 标签。
